namespace Asteroids
{
    public interface IHealth
    {
        void TakeDamage(int damage);
        void Demolition();
    }
}