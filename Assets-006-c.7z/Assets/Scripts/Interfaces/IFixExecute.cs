namespace Asteroids
{
    public interface IFixExecute
    {
        void FixExecute();
    }
}
