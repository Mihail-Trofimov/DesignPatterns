namespace Asteroids
{
    public interface IWeapon
    {
        void Shoot();
    }
}