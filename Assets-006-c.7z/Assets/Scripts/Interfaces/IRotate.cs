namespace Asteroids
{
    public interface IRotate
    {
        void Rotate();
    }
}