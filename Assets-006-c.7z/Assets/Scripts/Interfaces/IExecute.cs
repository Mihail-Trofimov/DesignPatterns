namespace Asteroids
{
    public interface IExecute
    {
        void Execute();
    }
}