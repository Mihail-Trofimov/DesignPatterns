using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Runtime.Serialization;
using UnityEngine;
using UnityRest;
//using System.Text.Json;
//using System.Text.Json.Serialization;

namespace Lesson_6.Task_3
{
    public class Lesson_6_Task_3 : MonoBehaviour
    {
        private const string _path = "Assets/Scripts/Lesson-6/config.json";
        private const string _pathToSave = "Assets/Scripts/Lesson-6/config2.json";
        private List<Unit> listUnit;
        private Factory _factory;

        private void Awake()
        {
            //Unit unit1 = new Unit("infantry", "200");
            //Root root1 = new Root(unit1);

            //Unit unit2 = new Unit("mag", "100");
            //Root root2 = new Root(unit2);

            //Unit unit3 = new Unit("infantry", "150");
            //Root root3 = new Root(unit3);




            //Root[] roots = new[] { root1, root2, root3 };

            //RootArray rootArray = new RootArray(roots);

            ////Units units = new Units();
            ////units.units = new Unit[] { unit1, unit2, unit3 };
            ////List<Root> unitList = new List<Root>();
            ////unitList.Add(root1);
            ////unitList.Add(root2);
            ////unitList.Add(root3);


            //SaveToJsonFile(_pathToSave, rootArray);
            /////*Units units = */LoadFromJsonFile<Units>(_path);
            _factory = new Factory();
            ////foreach (Unit unit in listUnit)
            ////{
            ////    _factory.Create(unit.type, unit.health);
            ////}
            ///

            Root[] roots = LoadFromJsonFile<Root>(_path);

            foreach (Root root in roots)
            {
                _factory.Create(root.unit.type, root.unit.health);
            }
        }

        private void SaveToJsonFile<T>(string path, T value)
        {
            string json = JsonUtility.ToJson(value, true);
            Debug.Log(json);
            //File.WriteAllText(path, Crypto.CryptoXOR(str));
            File.WriteAllText(path, json);
        }

        private T[] LoadFromJsonFile<T> (string path)
        {
            //string json = File.ReadAllText(path);
            //Debug.Log(json);
            //T value = JsonUtility.FromJson<T>(json);
            //return value;

            string json = File.ReadAllText(path);
            T[] value = JsonHelper.FromJson<T>(json);
            return value;




        }
    }

    public class Factory
    {
        private readonly FactoryInfantry _factoryInfantry = new FactoryInfantry();
        private readonly FactoryMag _factoryMag = new FactoryMag();

        public GameUnit Create(string type, string health)
        {
            if (type == FactoryInfantry.type)
            {
                return _factoryInfantry.Create(health);
            }
            else if (type == FactoryMag.type)
            {
                return _factoryMag.Create(health);
            }
            else
            {
                throw new DataException(nameof(Factory) + " does not contain " + type);
            }
        }


        public GameUnit CreateMag(string health)
        {
            GameUnit _unit = _factoryMag.Create(health);
            return _unit;
        }

        public GameUnit CreateInfantry(string health)
        {
            GameUnit _unit = _factoryInfantry.Create(health);
            return _unit;
        }
    }

    public class FactoryInfantry : IFactory
    {
        public static string type = "infantry";

        public GameUnit Create(string health)
        {
            GameUnit _unit = new GameUnit(type, health, new GameObject());
            return _unit;
        }
    }

    public class FactoryMag : IFactory
    {
        public static string type = "mag";

        public GameUnit Create(string health)
        {
            GameUnit _unit = new GameUnit(type, health, new GameObject());
            return _unit;
        }
    }

    public interface IFactory
    {
        GameUnit Create(string health);
    }


    [Serializable]
    public class RootArray
    {
        //[DataMember(Name = "unit")]
        public Root[] roots;

        public RootArray(Root[] roots)
        {
            this.roots = roots;
        }
    }

    [Serializable] public class Root
    {
        //[DataMember(Name = "unit")]
        public Unit unit;

        public Root(Unit unit)
        {
            this.unit = unit;
        }
    }

    [Serializable] public class Unit
    {
        //[DataMember(Name = "type")]
        //[JsonPropertyName("Wind")]
        public string type;

        //[DataMember(Name = "health")]
        public string health;

        public Unit(string type, string health)
        {
            this.type = type;
            this.health = health;
        }
    }

    public class GameUnit
    {
        public readonly string Type;
        public string Health;
        private GameObject _gameObject;

        public GameUnit(string type, string health, GameObject gameObject)
        {
            Type = type;
            Health = health;
            _gameObject = gameObject;
        }
    }
}