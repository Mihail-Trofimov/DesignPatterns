namespace Asteroids
{
    public interface IService
    {
        void Test();
    }
}
